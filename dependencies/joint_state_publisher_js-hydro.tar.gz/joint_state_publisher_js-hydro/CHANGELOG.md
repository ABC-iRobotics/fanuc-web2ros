2015-02-11 - **0.0.1**
 * Initial development of JointStatePublisherJS [(DLu)](https://github.com/DLu)

