/**
 * @author David V. Lu!! - davidvlu@gmail.com
 */

var JOINTSTATEPUBLISHER = JOINTSTATEPUBLISHER || {
  REVISION : '0.0.1'
};


