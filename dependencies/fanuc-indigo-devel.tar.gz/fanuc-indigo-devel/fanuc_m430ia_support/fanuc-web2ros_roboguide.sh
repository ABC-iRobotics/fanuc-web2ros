#!/bin/bash


sleep 3

echo "Starting fanuc web2ros and ros2web"
cd /home/irob/catkin_ws/src/fanuc-indigo-devel/fanuc_m430ia_support
node fanuc-ros2web.js -karel 192.168.1.101
node fanuc-web2ros.js -karel 192.168.1.101
